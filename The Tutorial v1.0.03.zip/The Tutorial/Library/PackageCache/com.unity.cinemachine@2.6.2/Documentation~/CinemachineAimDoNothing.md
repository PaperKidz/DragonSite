# Do Nothing

This Virtual Camera __Aim__ algorithm does not aim the Virtual Camera. Choose this algorithm for static shots or for animating the rotation directly with custom scripts.

