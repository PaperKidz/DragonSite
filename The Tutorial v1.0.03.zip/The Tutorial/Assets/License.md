Please Note: 
=============================
We are releasing the ADAM Characters, Animations and Environment under a custom EULA, which does not allow commercial use. 

The Asset accompanying this notice is a Restricted Asset pursuant to the Unity Asset Store EULA. Only a limited, non-exclusive, non-transferable, non-sublicensable license to the Asset for personal and non-commercial use is granted; no commercial use is permitted. Further, this license grant is subject to termination by Unity in its sole discretion at any time. 

Check out the ADAM blog series to learn more about Oats Studios and the ADAM production: 
https://blogs.unity3d.com/category/made-with-unity